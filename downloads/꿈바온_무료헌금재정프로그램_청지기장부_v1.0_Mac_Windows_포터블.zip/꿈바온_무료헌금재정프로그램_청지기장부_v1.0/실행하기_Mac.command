#!/bin/bash
cd "$(dirname "$0")"
echo "💰 꿈바온 무료 헌금·재정 프로그램 (선한 청지기 재정·헌금 장부 v1.0)을 시작합니다..."
python3 finance_desktop_app.py
