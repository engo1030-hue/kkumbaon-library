#!/bin/bash
cd "$(dirname "$0")"
open "꿈바온_설교AI_주간사역7종변환스튜디오_v1.0.html"
