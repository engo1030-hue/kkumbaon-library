@echo off
chcp 65001 > nul
cd /d "%~dp0"
echo 🐑 꿈바온 무료 교적 프로그램 (선한 목자의 양떼 수첩 v1.0)을 시작합니다...
python gyojeok_desktop_app.py
pause
