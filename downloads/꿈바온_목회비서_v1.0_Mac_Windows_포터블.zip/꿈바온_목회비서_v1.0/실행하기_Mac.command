#!/bin/bash
cd "$(dirname "$0")"
echo "🕊️ 꿈바온 목회 비서 스튜디오 (v1.0)를 시작합니다..."
python3 secretary_desktop_app.py
