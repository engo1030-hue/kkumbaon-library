@echo off
chcp 65001 > nul
start "" "%~dp0꿈바온_설교AI_주간사역7종변환스튜디오_v1.0.html"
