@echo off
chcp 65001 > nul
cd /d "%~dp0"
echo 💰 꿈바온 무료 헌금·재정 프로그램 (선한 청지기 재정·헌금 장부 v1.0)을 시작합니다...
python finance_desktop_app.py
pause
