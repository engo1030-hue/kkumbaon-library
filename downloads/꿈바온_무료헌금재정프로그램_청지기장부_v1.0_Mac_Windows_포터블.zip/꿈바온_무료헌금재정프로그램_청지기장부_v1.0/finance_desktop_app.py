#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
💰 꿈바온 무료 헌금·재정 프로그램 — 선한 청지기 재정·헌금 장부 (v1.0)
Mac & Windows 로컬 SQLite 데이터베이스 데스크톱 서버 엔진
- 외부 패키지 설치가 필요 없는 Python 표준 라이브러리 100% 기반
- 모든 성도 헌금·지출결의·기부금영수증 데이터를 내 컴퓨터의 data/finance.sqlite 에 실시간 영구 저장
- 실행 시마다 backups/ 폴더에 날짜별 자동 백업본 생성
"""

import os
import sys
import json
import sqlite3
import datetime
import threading
import webbrowser
from http.server import HTTPServer, SimpleHTTPRequestHandler

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
APP_DIR = os.path.join(ROOT_DIR, "app")
DATA_DIR = os.path.join(ROOT_DIR, "data")
BACKUP_DIR = os.path.join(ROOT_DIR, "backups")
DB_PATH = os.path.join(DATA_DIR, "finance.sqlite")

os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(BACKUP_DIR, exist_ok=True)

def init_db():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS finance_store (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            state_json TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )
    """)
    conn.commit()
    conn.close()

def load_state_from_db():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT state_json FROM finance_store WHERE id = 1")
    row = cur.fetchone()
    conn.close()
    if row and row[0]:
        try:
            return json.loads(row[0])
        except Exception:
            return None
    return None

def save_state_to_db(state_obj):
    raw_json = json.dumps(state_obj, ensure_ascii=False, indent=2)
    now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO finance_store (id, state_json, updated_at)
        VALUES (1, ?, ?)
        ON CONFLICT(id) DO UPDATE SET
            state_json = excluded.state_json,
            updated_at = excluded.updated_at
    """, (raw_json, now_str))
    conn.commit()
    conn.close()

    today_tag = datetime.datetime.now().strftime("%Y%m%d")
    backup_file = os.path.join(BACKUP_DIR, f"finance_auto_backup_{today_tag}.json")
    try:
        with open(backup_file, "w", encoding="utf-8") as f:
            f.write(raw_json)
    except Exception:
        pass

class FinanceRequestHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=APP_DIR, **kwargs)

    def log_message(self, format, *args):
        pass

    def do_GET(self):
        if self.path.startswith("/api/state"):
            st = load_state_from_db()
            payload = json.dumps(st if st else {}, ensure_ascii=False).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
            return
        return super().do_GET()

    def do_POST(self):
        if self.path.startswith("/api/state"):
            length = int(self.headers.get("Content-Length", "0"))
            body = self.rfile.read(length).decode("utf-8")
            try:
                data = json.loads(body)
                save_state_to_db(data)
                resp = json.dumps({"ok": True}).encode("utf-8")
                self.send_response(200)
            except Exception as e:
                resp = json.dumps({"ok": False, "error": str(e)}).encode("utf-8")
                self.send_response(400)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(resp)))
            self.end_headers()
            self.wfile.write(resp)
            return
        self.send_response(404)
        self.end_headers()

def main():
    init_db()
    port = 8795
    server = None
    for p in range(8795, 8825):
        try:
            server = HTTPServer(("127.0.0.1", p), FinanceRequestHandler)
            port = p
            break
        except OSError:
            continue

    if server is None:
        print("포트 할당에 실패했습니다.")
        sys.exit(1)

    url = f"http://127.0.0.1:{port}/index.html"
    print("=" * 68)
    print("  💰 꿈바온 무료 헌금·재정 프로그램 — 선한 청지기 재정·헌금 장부 (v1.0)")
    print(f"  📂 로컬 데이터베이스: {DB_PATH}")
    print(f"  📂 일일 자동 백업폴더: {BACKUP_DIR}")
    print(f"  🌐 실행 주소: {url}")
    print("  (프로그램 사용을 마치신 뒤 이 창을 닫으시면 안전하게 종료됩니다)")
    print("=" * 68)

    threading.Timer(0.6, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n프로그램을 안전하게 종료합니다.")
        server.server_close()

if __name__ == "__main__":
    main()
