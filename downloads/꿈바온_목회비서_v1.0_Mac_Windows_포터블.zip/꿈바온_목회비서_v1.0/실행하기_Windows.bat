@echo off
chcp 65001 > nul
cd /d "%~dp0"
echo 🕊️ 꿈바온 목회 비서 스튜디오 (v1.0)를 시작합니다...
python secretary_desktop_app.py
pause
